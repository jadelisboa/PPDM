import { createDrawerNavigator } from '@react-navigation/drawer';

const Drawer = createDrawerNavigator();

<NavigationContainer>
    <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Profile" component={ProfileScreen} />
    </Drawer.Navigator>
</NavigationContainer>