import React from 'react'
import { createStackNavigation } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './HomeScreen';
import DetailsScreen from 'DetailsScreen';

const Stack = createStackNavigation();

function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Home">
                <Stack.Screen name="Home" components={HomeScreen} />
                <Stack.Screen name="Details" components={DetailsScreen} />
            </Stack.Navigator>
        </NavigationContainer>
    )
}