import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
//npm install @react-navigation/bottom-tabs
import { Ionicons } from 'expo/vector-icons';

const Tab = createBottomTabNavigator();

<Tab.Navigator screenOptions={({ route }) => {
    tabBarIcon: ({color, size}) => {
        let iconName = route.name === 'Home' ?  'home' : 'person';
        return <Ionicons name= {iconName} size= {size} color= {color}/>

        // = (atributo)
        // == (igual independente do tipo)
        // === (igual dependente do tipo)
        // ? (condição - se verdadeiro: se falso (if))
    
    }
}
}>
    <Tab.Screen name="Settings" component="SettingsScreen"/>
    <Tab.Screen name="Home" component="HomeScreen"/>

</Tab.Navigator>

