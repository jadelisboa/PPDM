import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { listarBikes } from '../controller/BikeController';

export default function TelaInicial({ navigation }) {
const dados = listarBikes();

const renderItem = ({ item }) => (
<TouchableOpacity
style={styles.item}
onPress={() => navigation.navigate('TelaDetalhes', { bikeId: item.id })}
>
<Text style={styles.title}>{item.nome}</Text>
</TouchableOpacity>
);

return (
<View style={styles.container}>
{dados.length === 0 ? (
<Text style={styles.alert}>Nenhuma bicicleta disponível.</Text>
) : (
<FlatList
data={dados}
renderItem={renderItem}
keyExtractor={item => item.id}
/>
)}
</View>
);
}

const styles = StyleSheet.create({
container: { flex: 1, padding: 16 },
item: { padding: 16, backgroundColor: '#e0ffe0', marginBottom: 10, borderRadius: 8 },
title: { fontSize: 18 },
alert: { fontSize: 16, color: 'red' },
});  