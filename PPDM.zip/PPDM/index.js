import React from "react";
import {createStackNavigator} from '@react-native/stack';
import TelaInicial from "./TelaIInicial";
import TelaDetalhes from './TelaDetalhes';

const Stack = createNativeStackNavigator();

export default function Routes(){
    return(
        <Stack.Navigator>
            <Stack.Screen name='TelaInicial' component={TelaInicial} options={{title: 'Bicicletas'}}/>
            <Stack.Screen name='TelaDetalhes' component={TelaDetalhes} options={{title: 'Detalhes'}}/>
        </Stack.Navigator>
    )
}