export const bikes = [
    {
        id: '1',
        nome: 'bicicleta ecológica de bambu',
        descricao: 'essa é a nossa mais nova bicicleta, venha adquirir!',
    },
    {
        id: '2',
        nome: 'bicicleta ecológica 2',
        descricao: 'Compre agora ! Poucas unidades'
    },
    {
        id: 'speed bike',
        nome: 'bicicleta ecológica 3',
        descricao: 'bicicleta ecológica veloz',
    },

];

//isso é uma MOCK